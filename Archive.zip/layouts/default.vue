<template>
  <div>

    <nuxt />

  </div>
</template>
<script>

export default {
  components: {
 
  },
}
</script>

<style>
html {
  font-family: lato, Times, serif, -apple-system, BlinkMacSystemFont, 'Segoe UI',
    Roboto, 'Helvetica Neue', Arial, sans-serif;
  font-size: 16px;
  word-spacing: 1px;
  -ms-text-size-adjust: 100%;
  -webkit-text-size-adjust: 100%;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  box-sizing: border-box;
  overflow-x: hidden;
}


*,
*:before,
*:after {
  box-sizing: border-box;
  margin: 0;
}
body {
    overflow-x: hidden;
}
:root {
  --background: #F8F2E7;
  --redBody: #9c3135; 
  --green: #3e834e; 
  --green-rhum: #155323; 
  --body: #4e4e4e;
  --white: #fff;
  --black: #202020;
}








</style>
